set ex;

reset;

clear;

docker login
