set ex;

reset;

clear;

docker build -t softwareshinobi/dwity-universe:latest .
