set ex;

reset;

clear;

firefox localhost:80 &
