set ex;

#docker run -d -p 8082:80 softwareshinobi/dwity-universe:latest .

docker-compose up -d
